QuickShop - Mobile Computing Assignment 1
Student: Hafiz Muhammad Ammar Ali
Roll No: 2502123
Section: BS IT 3B

Open QuickShop in Android Studio or VS Code.
Run: flutter pub get
Run: flutter run -d emulator-5554

Flutter 3.47.4. Debug APK built successfully and installed in Android emulator.
Test command: flutter test (2 tests passed).
GitHub: https://github.com/hmaplays/Lab_1

The Screenshots folder contains genuine Android emulator captures.
Note: the WebView screen displayed the address and loading indicator, but the external site did not finish loading during the emulator test.
